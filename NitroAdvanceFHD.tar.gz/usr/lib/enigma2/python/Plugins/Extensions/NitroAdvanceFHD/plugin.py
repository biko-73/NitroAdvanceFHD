#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function

#This plugin is free software, you are allowed to
#modify it (if you keep the license),
#but you are not allowed to distribute/publish
#it without source code (this version and your modifications).
#This means you also have to distribute
#source code of your modifications.

# for localized messages
from .__init__ import _
from enigma import eTimer, getDesktop
from Components.ActionMap import ActionMap
from Tools.Directories import *
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.SkinSelector import SkinSelector
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Tools.Notifications import AddPopup
from os import listdir, remove, rename, system, path, symlink, chdir, makedirs, mkdir
from os import path as os_path, remove as os_remove
import shutil
import re, os

from six.moves.urllib.request import urlretrieve
from .compat import compat_urlopen, compat_Request, compat_URLError, PY3

cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')

reswidth = getDesktop(0).size().width()

config.plugins.NitroAdvanceFHD = ConfigSubsection()

REDC = '\033[31m'
ENDC = '\033[m'

def cprint(text):
    print(REDC + text + ENDC)

def removeunicode(data):
    try:
        try:
                data = data.encode('utf', 'ignore')
        except:
                pass
        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass
    return data

def Plugins(**kwargs):
    return [PluginDescriptor(name=_("NitroAdvanceFHD Config tool"), description=_("NitroAdvanceFHD (Skin by Kaleem_Club)"), where = [PluginDescriptor.WHERE_PLUGINMENU],
    icon="plugin.png", fnc=main)]

def main(session, **kwargs):
    if config.skin.primary_skin.value == "NitroAdvanceFHD/skin.xml":
        session.open(NitroAdvanceFHD_Config)
    else:
        AddPopup(_('Please activate NitroAdvanceFHD Skin before run the Config Plugin'), type=MessageBox.TYPE_ERROR, timeout=10)
        return []

def isInteger(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

class NitroAdvanceFHD_Config(Screen, ConfigListScreen):

    skin = """
  <screen name="NitroAdvanceFHD_Config" position="center,center" size="1300,700" title="NitroAdvanceFHD Setup">
    <ePixmap position="0,0" size="1300,700" pixmap="NitroAdvanceFHD/construct/backgrounds/background_Kaleem_Club.png" alphatest="blend" zPosition="-50" />
    <widget name="config" position="25,25" size="600,360" font="Regular;34" itemHeight="45" enableWrapAround="1" transparent="1" />
    <widget name="Picture" position="660,25" size="600,360" alphatest="on" />
    <ePixmap pixmap="NitroAdvanceFHD/buttons/red45x45.png" position="20,650" size="45,45" alphatest="blend" />
    <ePixmap pixmap="NitroAdvanceFHD/buttons/green45x45.png" position="315,650" size="45,45" alphatest="blend" />
    <ePixmap pixmap="NitroAdvanceFHD/buttons/yellow45x45.png" position="610,650" size="45,45" alphatest="blend" />
    <ePixmap pixmap="NitroAdvanceFHD/buttons/blue45x45.png" position="905,650" size="45,45" alphatest="blend" />
    <widget name="key_red" position="65,650" size="250,45" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="background" transparent="1" foregroundColor="foreground" />
    <widget name="key_green" position="360,650" size="250,45" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="background" transparent="1" foregroundColor="foreground" />
    <widget name="key_yellow" position="655,650" size="250,45" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="background" transparent="1" foregroundColor="foreground" />
    <widget name="key_blue" position="950,650" size="250,45" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="background" transparent="1" foregroundColor="foreground" />
    <!-- ***** Temperature ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="20,430" size="200,200" scale="1" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,current,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
   </widget>
    <widget source="session.MSNWeather" render="Label" position="220,430" size="200,200" font="Regular; 150" halign="center" backgroundColor="background_purple" transparent="1" zPosition="2">
      <convert type="MSNWeather">temperature_current</convert>
    </widget>
    <!-- ***** Location ***** -->
    <widget source="session.MSNWeather" render="Label" position="420,550" size="240,80" font="Regular; 30 halign="center" backgroundColor="background_purple" transparent="1" zPosition="2" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">city</convert>
    </widget>
    <!-- ***** Wind ***** -->
   <widget source="session.MSNWeather" render="Label" position="420,470" size="240,80" font="Regular; 30 halign="center" backgroundColor="background" transparent="1" zPosition="2" noWrap="1">
      <convert type="MSNWeather">winddisplay</convert>
    </widget>
    <!-- ***** Temperature day-3 ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="697,400" size="150,150" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,day3,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="697,550" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">weekday,day3</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="697,590" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" noWrap="1">
      <convert type="MSNWeather">temperature_heigh_low,day3</convert>
    </widget>
    <!-- ***** Temperature day-4 ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="887,400" size="150,150" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,day4,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="887,550" size="150,40" font="Regular; 25" halign="left" backgroundColor="background_purple" transparent="1" zPosition="12" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">weekday,day4</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="887,590" size="150,40" font="Regular; 25" halign="left" backgroundColor="background_purple" transparent="1" zPosition="12" noWrap="1">
      <convert type="MSNWeather">temperature_heigh_low,day4</convert>
   </widget>
    <!-- ***** Temperature day-5 ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="1080,400" size="150,150" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,day5,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="1080,550" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">weekday,day5</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="1080,590" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" noWrap="1">
      <convert type="MSNWeather">temperature_heigh_low,day5</convert>
    </widget>
  </screen>
    """

    def __init__(self, session, args = 0):
        self.session = session
        self.changed_screens = False
        Screen.__init__(self, session)

        self.start_skin = config.skin.primary_skin.value
        if self.start_skin != "skin.xml":
            self.getInitConfig()

        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self.configChanged = False
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("OK"))
        self["key_yellow"] = Label()
        self["key_blue"] = Label(_("About"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
                {
                        "green": self.keyGreen,
                        "red": self.cancel,
                        "yellow": self.keyYellow,
                        "blue": self.about,
                        "cancel": self.cancel,
                }, -2)

        self["Picture"] = Pixmap()

        if not self.selectionChanged in self["config"].onSelectionChanged:
            self["config"].onSelectionChanged.append(self.selectionChanged)
        self.createConfigList()
        if self.start_skin == "skin.xml":
            self.onLayoutFinish.append(self.openSkinSelectorDelayed)
        else:
            self.createConfigList()

    def getInitConfig(self):

        global cur_skin

        self.title = _("%s Setup" % cur_skin)
        self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
        cprint("self.skin_base_dir=%s, skin=%s, currentSkin=%s" % (self.skin_base_dir, config.skin.primary_skin.value, cur_skin))

        self.default_font_file = "font_Original.xml"
        self.default_color_file = "color_Original.xml"
        self.default_interface_file = "interface_Original.xml"

        self.color_file = "skin_user_color.xml"
        self.interface_file = "skin_user_interface.xml"

        # color
        current, choices = self.getSettings(self.default_color_file, self.color_file)
        self.NitroAdvanceFHD_color = NoSave(ConfigSelection(default=current, choices = choices))
        # interface
        current, choices = self.getSettings(self.default_interface_file, self.interface_file)
        self.NitroAdvanceFHD_interface = NoSave(ConfigSelection(default=current, choices = choices))
        # myatile
        myatile_active = self.getmyAtileState()
        self.NitroAdvanceFHD_active = NoSave(ConfigYesNo(default=myatile_active))
        self.NitroAdvanceFHD_fake_entry = NoSave(ConfigNothing())

    def getSettings(self, default_file, user_file):
        # default setting
        default = ("default", _("Default"))

        # search typ
        styp = default_file.replace('_Original.xml', '')
        search_str = '%s_' % styp

        # possible setting
        choices = []
        files = listdir(self.skin_base_dir)
        if path.exists(self.skin_base_dir + 'allScreens/%s/' % styp):
            files += listdir(self.skin_base_dir + 'allScreens/%s/' % styp)
        for f in sorted(files, key=str.lower):
            if f.endswith('.xml') and f.startswith(search_str):
                friendly_name = f.replace(search_str, "").replace(".xml", "").replace("_", " ")
                if path.exists(self.skin_base_dir + 'allScreens/%s/%s' %(styp, f)):
                    choices.append((self.skin_base_dir + 'allScreens/%s/%s' %(styp, f), friendly_name))
                else:
                    choices.append((self.skin_base_dir + f, friendly_name))
        choices.append(default)

        # current setting
        myfile = self.skin_base_dir + user_file
        current = ''
        if not path.exists(myfile):
            if path.exists(self.skin_base_dir + default_file):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(default_file, user_file)
            elif path.exists(self.skin_base_dir + 'allScreens/%s/%s' % (styp, default_file)):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(self.skin_base_dir + 'allScreens/%s/%s' %(styp, default_file), user_file)
            else:
                current = None
        if current is None:
            current = default
        else:
            filename = path.realpath(myfile)
            friendly_name = path.basename(filename).replace(search_str, "").replace(".xml", "").replace("_", " ")
            current = (filename, friendly_name)

        return current[0], choices

        #SELECTED Skins folder - We use different folder name (more meaningfull) for selections
        if path.exists(self.skin_base_dir + "mySkin_off"):
            if not path.exists(self.skin_base_dir + "NitroAdvanceFHD_Selections"):
                chdir(self.skin_base_dir)
                try:
                    rename("mySkin_off", "NitroAdvanceFHD_Selections")
                except:
                    pass

    def createConfigList(self):
        self.set_color = getConfigListEntry(_("Color:"), self.NitroAdvanceFHD_color)
        self.set_interface = getConfigListEntry(_("Interface:"), self.NitroAdvanceFHD_interface)
        self.set_myatile = getConfigListEntry(_("Enable %s pro:") % cur_skin, self.NitroAdvanceFHD_active)
        self.set_new_skin = getConfigListEntry(_("Change skin"), ConfigNothing())
        self.LackOfFile = ''
        self.list = []
        self.list.append(self.set_myatile)
        if len(self.NitroAdvanceFHD_color.choices)>1:
            self.list.append(self.set_color)
        if len(self.NitroAdvanceFHD_interface.choices)>1:
            self.list.append(self.set_interface)
        self.list.append(self.set_new_skin)
        self["config"].list = self.list
        self["config"].l.setList(self.list)
        if self.NitroAdvanceFHD_active.value:
            self["key_yellow"].setText("%s pro" % cur_skin)
        else:
            self["key_yellow"].setText("")

    def changedEntry(self):
        self.configChanged = True 
        if self["config"].getCurrent() == self.set_color:
            self.setPicture(self.NitroAdvanceFHD_color.value)
        elif self["config"].getCurrent() == self.set_interface:
            self.setPicture(self.NitroAdvanceFHD_interface.value)
        elif self["config"].getCurrent() == self.set_myatile:
            if self.NitroAdvanceFHD_active.value:
                self["key_yellow"].setText("%s pro" % cur_skin)
            else:
                self["key_yellow"].setText("")
            self.createConfigList()

    def selectionChanged(self):
        if self["config"].getCurrent() == self.set_color:
            self.setPicture(self.NitroAdvanceFHD_color.value)
        elif self["config"].getCurrent() == self.set_interface:
            self.setPicture(self.NitroAdvanceFHD_interface.value)
        else:
            self["Picture"].hide()

    def cancel(self):
        if self["config"].isChanged():
            self.session.openWithCallback(self.cancelConfirm, MessageBox, _("Really close without saving settings?"), MessageBox.TYPE_YESNO, default = False)
        else:
            for x in self["config"].list:
                x[1].cancel()
            if self.changed_screens:
                self.restartGUI()
            else:
                self.close()

    def cancelConfirm(self, result):
        if result == None or result == False:
            print("[%s]: Cancel confirmed." % cur_skin)
        else:
            print("[%s]: Cancel confirmed. Config changes will be lost." % cur_skin)
            for x in self["config"].list:
                    x[1].cancel()
            self.close()

    def getmyAtileState(self):
        chdir(self.skin_base_dir)
        if path.exists("mySkin"):
            return True
        else:
            return False

    def setPicture(self, f):
        pic = f.split('/')[-1].replace(".xml", ".png")
        preview = self.skin_base_dir + "preview/preview_" + pic
        if path.exists(preview):
            self["Picture"].instance.setPixmapFromFile(preview)
            self["Picture"].show()
        else:
            self["Picture"].hide()

    def keyYellow(self):
        if self.NitroAdvanceFHD_active.value:
            self.session.openWithCallback(self.NitroAdvanceFHDScreenCB, NitroAdvanceFHDScreens)
        else:
            self["config"].setCurrentIndex(0)

    def openSkinSelector(self):
        self.session.openWithCallback(self.skinChanged, SkinSelector)

    def openSkinSelectorDelayed(self):
        self.delaytimer = eTimer()
        self.delaytimer.callback.append(self.openSkinSelector)
        self.delaytimer.start(200, True)

    def skinChanged(self, ret = None):
        global cur_skin
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        if cur_skin == "skin.xml":
            self.restartGUI()
        else:
            self.getInitConfig()
            self.createConfigList()

    def keyGreen(self):
        if self["config"].isChanged():
            for x in self["config"].list:
                    x[1].save()
            chdir(self.skin_base_dir)
            # color
            self.makeSettings(self.NitroAdvanceFHD_color, self.color_file)
            # interface
            self.makeSettings(self.NitroAdvanceFHD_interface, self.interface_file)
            #Pro SCREENS
            if not path.exists("mySkin_off"):
                mkdir("mySkin_off")
                print("makedir mySkin_off")
            if self.NitroAdvanceFHD_active.value:
                if not path.exists("mySkin") and path.exists("mySkin_off"):
                    symlink("mySkin_off", "mySkin")
            else:
                if path.exists("mySkin"):
                    if path.exists("mySkin_off"):
                        if path.islink("mySkin"):
                            remove("mySkin")
                        else:
                            shutil.rmtree("mySkin")
                    else:
                        rename("mySkin", "mySkin_off")
            self.update_user_skin()
            self.restartGUI()
        elif  config.skin.primary_skin.value != self.start_skin:
            self.update_user_skin()
            self.restartGUI()
        else:
            if self.changed_screens:
                self.update_user_skin()
                self.restartGUI()
            else:
                self.close()

    def makeSettings(self, config_entry, user_file):
        if path.exists(user_file):
            remove(user_file)
        if path.islink(user_file):
            remove(user_file)
        if config_entry.value != 'default':
            symlink(config_entry.value, user_file)

    def NitroAdvanceFHDScreenCB(self):
        self.changed_screens = True
        self["config"].setCurrentIndex(0)

    def restartGUI(self):
        myMessage = ''
        if self.LackOfFile != '':
            cprint("missing components: %s" % self.LackOfFile)
            myMessage += _("Missing components found: %s\n\n") % self.LackOfFile
            myMessage += _("Skin will NOT work properly!!!\n\n")
        restartbox = self.session.openWithCallback(self.restartGUIcb, MessageBox, _("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_("Message"))

    def about(self):
        self.session.open(NitroAdvanceFHD_About)

    def restartGUIcb(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def update_user_skin(self):
        global cur_skin
        user_skin_file = resolveFilename(SCOPE_CONFIG, 'skin_user_' + cur_skin + '.xml')
        if path.exists(user_skin_file):
            remove(user_skin_file)
        cprint("update_user_skin.self.NitroAdvanceFHD_active.value")
        user_skin = ""
        if path.exists(self.skin_base_dir + self.color_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.color_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.interface_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.interface_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + 'mySkin'):
            for f in listdir(self.skin_base_dir + "mySkin/"):
                user_skin = user_skin + self.readXMLfile(self.skin_base_dir + "mySkin/" + f, 'screen')
        if user_skin != '':
            user_skin = "<skin>\n" + user_skin
            user_skin = user_skin + "</skin>\n"
            with open(user_skin_file, "w") as myFile:
                cprint("update_user_skin.self.NitroAdvanceFHD_active.value write myFile")
                myFile.write(user_skin)
                myFile.flush()
                myFile.close()
        #checking if all renderers converters are in system
        self.checkComponent(user_skin, 'render', resolveFilename(SCOPE_PLUGINS, '../Components/Renderer/') )
        self.checkComponent(user_skin, 'Convert', resolveFilename(SCOPE_PLUGINS, '../Components/Converter/') )
        self.checkComponent(user_skin, 'pixmap', resolveFilename(SCOPE_SKIN, '') )
               
    def checkComponent(self, myContent, look4Component, myPath): #look4Component=render|
        def updateLackOfFile(name, mySeparator =', '):
                cprint("Missing component found:%s\n" % name)
                if self.LackOfFile == '':
                        self.LackOfFile = name
                else:
                        self.LackOfFile += mySeparator + name
            
        r=re.findall( r' %s="([a-zA-Z0-9_/\.]+)" ' % look4Component, myContent )
        r=list(set(r)) #remove duplicates, no need to check for the same component several times

        cprint("Found %s:\n" % (look4Component))
        print(r)
        if r:
                for myComponent in set(r):
                        if look4Component == 'pixmap':
                                if myComponent.startswith('/'):
                                        if not path.exists(myComponent):
                                                updateLackOfFile(myComponent, '\n')
                                else:
                                        if not path.exists(myPath + myComponent):
                                                updateLackOfFile(myComponent)
                        else:
                                if not path.exists(myPath + myComponent + ".pyo") and not path.exists(myPath + myComponent + ".py") and not path.exists(myPath + myComponent + ".pyc"):
                                        updateLackOfFile(myComponent)
        return
    
    def readXMLfile(self, XMLfilename, XMLsection): #sections:ALLSECTIONS|fonts|
        myPath=path.realpath(XMLfilename)
        if not path.exists(myPath):
                remove(XMLfilename)
                return ''
        filecontent = ''
        if XMLsection == 'ALLSECTIONS':
                sectionmarker = True
        else:
                sectionmarker = False
        with open (XMLfilename, "r") as myFile:
                for line in myFile:
                        if line.find('<skin>') >= 0 or line.find('</skin>') >= 0:
                                continue
                        if line.find('<%s' %XMLsection) >= 0 and sectionmarker == False:
                                sectionmarker = True
                        elif line.find('</%s>' %XMLsection) >= 0 and sectionmarker == True:
                                sectionmarker = False
                                filecontent = filecontent + line
                        if sectionmarker == True:
                                filecontent = filecontent + line
                myFile.close()
        return filecontent

class NitroAdvanceFHD_About(Screen):

    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
                {
                        "cancel": self.cancel,
                        "ok": self.keyOk,
                }, -2)

    def keyOk(self):
        self.close()

    def cancel(self):
        self.close()

class NitroAdvanceFHDScreens(Screen):

    skin = """
  <screen name="NitroAdvanceFHDScreens" position="310,190" size="1300,700" title="NitroAdvanceFHD Setup" backgroundColor="transparent">
    <ePixmap position="0,0" size="1300,700" pixmap="NitroAdvanceFHD/construct/backgrounds/background_Kaleem_Club.png" alphatest="blend" zPosition="-50" />
      <widget source="menu" render="Listbox" position="25,25" size="600,360" scrollbarMode="showNever" enableWrapAround="1" transparent="1">
        <convert type="TemplatedMultiContent">
                                    {"template":
                                            [
                                                    MultiContentEntryPixmapAlphaTest(pos = (2, 2), size = (25, 24), png = 2),
                                                    MultiContentEntryText(pos = (35, 4), size = (500, 24), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 1),
                                            ],
                                            "fonts": [gFont("Regular", 22),gFont("Regular", 16)],
                                            "itemHeight": 30
        
        }
      </convert>
    </widget>
    <widget name="Picture" position="660,25" size="600,360" alphatest="on" />
    <ePixmap pixmap="NitroAdvanceFHD/buttons/red45x45.png" position="20,650" size="45,45" alphatest="blend" />
    <ePixmap pixmap="NitroAdvanceFHD/buttons/green45x45.png" position="315,650" size="45,45" alphatest="blend" />
    <widget name="key_red" position="65,650" size="250,45" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="background" transparent="1" foregroundColor="foreground" />
    <widget name="key_green" position="360,650" size="250,45" zPosition="1" font="Regular;30" halign="center" valign="center" backgroundColor="background" transparent="1" foregroundColor="foreground" />
    <!-- ***** Temperature ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="20,430" size="200,200" scale="1" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,current,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="220,430" size="200,200" font="Regular; 150" halign="center" backgroundColor="background_purple" transparent="1" zPosition="2">
      <convert type="MSNWeather">temperature_current</convert>
    </widget>
    <!-- ***** Location ***** -->
    <widget source="session.MSNWeather" render="Label" position="420,550" size="240,80" font="Regular; 30 halign="center" backgroundColor="background_purple" transparent="1" zPosition="2" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">city</convert>
    </widget>
    <!-- ***** Wind ***** -->
    <widget source="session.MSNWeather" render="Label" position="420,470" size="240,80" font="Regular; 30 halign="center" backgroundColor="background" transparent="1" zPosition="2" noWrap="1">
      <convert type="MSNWeather">winddisplay</convert>
    </widget>
    <!-- ***** Temperature day-3 ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="697,400" size="150,150" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,day3,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="697,550" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">weekday,day3</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="697,590" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" noWrap="1">
      <convert type="MSNWeather">temperature_heigh_low,day3</convert>
    </widget>
    <!-- ***** Temperature day-4 ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="887,400" size="150,150" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,day4,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="887,550" size="150,40" font="Regular; 25" halign="left" backgroundColor="background_purple" transparent="1" zPosition="12" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">weekday,day4</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="887,590" size="150,40" font="Regular; 25" halign="left" backgroundColor="background_purple" transparent="1" zPosition="12" noWrap="1">
      <convert type="MSNWeather">temperature_heigh_low,day4</convert>
    </widget>
    <!-- ***** Temperature day-5 ***** -->
    <widget render="MSNWeatherPixmap" source="session.MSNWeather" position="1080,400" size="150,150" zPosition="12" alphatest="blend">
      <convert type="MSNWeather">weathericon,day5,/usr/share/enigma2/NitroAdvanceFHD/weather_icons/,png</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="1080,550" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" foregroundColor="foreground_offwhite" noWrap="1">
      <convert type="MSNWeather">weekday,day5</convert>
    </widget>
    <widget source="session.MSNWeather" render="Label" position="1080,590" size="150,40" font="Regular; 25" halign="center" backgroundColor="background_purple" transparent="1" zPosition="12" noWrap="1">
      <convert type="MSNWeather">temperature_heigh_low,day5</convert>
    </widget>
  </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        global cur_skin
        self.is_atile = False
        if cur_skin == 'NitroAdvanceFHD':
            self.is_atile = True

        self.title = _("%s additional screens") % cur_skin
        try:
            self["title"]=StaticText(self.title)
        except:
            print('self["title"] was not found in skin')

        self["key_red"] = StaticText(_("Exit"))
        self["key_green"] = StaticText(_("on"))
        self["Picture"] = Pixmap()
        menu_list = []
        self["menu"] = List(menu_list)
        self["shortcuts"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"],
        {
                "ok": self.runMenuEntry,
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "green": self.runMenuEntry,
        }, -2)

        self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
        self.screen_dir = "allScreens"
        self.skinparts_dir = "skinparts"
        self.file_dir = "mySkin_off"
        my_path = resolveFilename(SCOPE_SKIN, "%s/icons/lock_on.png" % cur_skin)
        if not path.exists(my_path):
            my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_on.png")
        self.enabled_pic = LoadPixmap(cached = True, path = my_path)
        my_path = resolveFilename(SCOPE_SKIN, "%s/icons/lock_off.png" % cur_skin)
        if not path.exists(my_path):
            my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_off.png")
        self.disabled_pic = LoadPixmap(cached = True, path = my_path)

        if not self.selectionChanged in self["menu"].onSelectionChanged:
            self["menu"].onSelectionChanged.append(self.selectionChanged)

        self.onLayoutFinish.append(self.createMenuList)

    def selectionChanged(self):
        sel = self["menu"].getCurrent()
        if sel is not None:
            self.setPicture(sel[0])
            if sel[2] == self.enabled_pic:
                self["key_green"].setText(_("off"))
            elif sel[2] == self.disabled_pic:
                self["key_green"].setText(_("on"))

    def createMenuList(self):
        chdir(self.skin_base_dir)
        f_list = []
        dir_path = self.skin_base_dir + self.screen_dir
        if not path.exists(dir_path):
            makedirs(dir_path)
        dir_skinparts_path = self.skin_base_dir + self.skinparts_dir
        if not path.exists(dir_skinparts_path):
            makedirs(dir_skinparts_path)
        file_dir_path = self.skin_base_dir + self.file_dir
        if not path.exists(file_dir_path):
            makedirs(file_dir_path)
        dir_global_skinparts = resolveFilename(SCOPE_SKIN, "skinparts")
        if path.exists(dir_global_skinparts):
            for pack in listdir(dir_global_skinparts):
                if path.isdir(dir_global_skinparts + "/" + pack):
                    for f in listdir(dir_global_skinparts + "/" + pack):
                        if path.exists(dir_global_skinparts + "/" + pack + "/" + f + "/" + f + "_Atile.xml"):
                            if not path.exists(dir_path + "/skin_" + f + ".xml"):
                                symlink(dir_global_skinparts + "/" + pack + "/" + f + "/" + f + "_Atile.xml", dir_path + "/skin_" + f + ".xml")
                            if not path.exists(dir_skinparts_path + "/" + f):
                                symlink(dir_global_skinparts + "/" + pack + "/" + f, dir_skinparts_path + "/" + f)
        list_dir = sorted(listdir(dir_path), key=str.lower)
        for f in list_dir:
            if f.endswith('.xml') and f.startswith('skin_'):
                if (not path.islink(dir_path + "/" + f)) or os.path.exists(os.readlink(dir_path + "/" + f)):
                    friendly_name = f.replace("skin_", "")
                    friendly_name = friendly_name.replace(".xml", "")
                    friendly_name = friendly_name.replace("_", " ")
                    linked_file = file_dir_path + "/" + f
                    if path.exists(linked_file):
                        if path.islink(linked_file):
                            pic = self.enabled_pic
                        else:
                            remove(linked_file)
                            symlink(dir_path + "/" + f, file_dir_path + "/" + f)
                            pic = self.enabled_pic
                    else:
                        pic = self.disabled_pic
                    f_list.append((f, friendly_name, pic))
                else:
                    if path.islink(dir_path + "/" + f):
                        remove(dir_path + "/" + f)
        menu_list = [ ]
        for entry in f_list:
            menu_list.append((entry[0], entry[1], entry[2]))
        self["menu"].updateList(menu_list)
        self.selectionChanged()

    def setPicture(self, f):
        pic = f.replace(".xml", ".png")
        preview = self.skin_base_dir + "preview/preview_" + pic
        if path.exists(preview):
            self["Picture"].instance.setPixmapFromFile(preview)
            self["Picture"].show()
        else:
            self["Picture"].hide()

    def keyCancel(self):
        self.close()

    def runMenuEntry(self):
        sel = self["menu"].getCurrent()
        if sel is not None:
            if sel[2] == self.enabled_pic:
                remove(self.skin_base_dir + self.file_dir + "/" + sel[0])
            elif sel[2] == self.disabled_pic:
                symlink(self.skin_base_dir + self.screen_dir + "/" + sel[0], self.skin_base_dir + self.file_dir + "/" + sel[0])
            self.createMenuList()
